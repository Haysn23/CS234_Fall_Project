
package jobpostproject;

import java.util.Scanner;

/**
 *
 * @author natha
 */
public class JobPostProject {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) throws Exception {
        Request Request = new Request();
        Approval Approval = new Approval();
        Scanner in = new Scanner(System.in);
    int Choice;
    Request.jPostLoad();
    
    do {
        System.out.println("Job Posting Handler");
        System.out.println("");
        System.out.println("Main Menu:");
        System.out.println("");
        System.out.println("1. Create new Job Posting: ");
        System.out.println("2. View open Job Postings: ");
        System.out.println("3. Approval Portal:");
        System.out.println("4. Delete Job Posting:");
        System.out.println("5. Save Records:");
        System.out.println("6. Exit ");
        System.out.println("");
        System.out.println("Please enter menu choice: ");
        
        Choice = in.nextInt();
        
        if(Choice !=1 && Choice !=2 && Choice !=3 && Choice !=4 && Choice !=5&& Choice !=6){
             System.out.println("Invalid choice. Please enter a valid option. ");
                in.reset(); 
        }
        switch(Choice){
            
            case 1 -> {
                Request.getjInfo();
                Request.reviewjPost();
                Request.sendtoApproval();
                
                    //jobPosting test = new jobPosting(01,jType,jexType,jPosistion,jDescription,jSchedule,jStatus);
                }
            case 2 -> {
                System.out.println("View open Job Postings: ");
                System.out.println();
                Request.view();
                
               
                }
            case 3 -> {
                
                System.out.println();
                Request.viewExpedited();
                Approval.approvalMenu();
                
          
                }
            case 4 -> {
                int jppID = 0;
                System.out.println();
               Request.removeJPost(jppID);
            }   
            case 5 -> {
               Request.jPostSave();
                
          
                }
            case 6 -> {
                System.out.println("Goodbye!");
                return;
            }
            default -> System.out.println("Enter correct number:");
        
    }
        
    } while (Choice <=6);
   
    
}
   
}