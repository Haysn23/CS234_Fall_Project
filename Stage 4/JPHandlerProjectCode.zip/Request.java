
package jobpostproject;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.Random;

/**
 *
 * @author Nathan Hays
 */
public class Request{
    
    private static LinkedList<jobPosting> jP1 = new LinkedList<>();
    private static jobPosting test;
   static int jID;
   static String jType;
   static String jexType;
   static String jPosistion;
   static String jDescription;
   static String jLocation;
   static String jSchedule;
   static String jStatus;
   static String reviewAns;
   static String approveAns;
  
    static Scanner in = new Scanner(System.in); 
    
    /**
     * This method asks the user to enter information about the job posting.
     */
    public  void getjInfo(){
        
        //jID = 1+jID;
        
        // User questions and data collection begins for Job Post Data
        
        System.out.println("Please enter the Job Type: (Internal or External) ");
            jType = in.nextLine();
            
            // If the the answer to job type is external or External then the question for External Job type is asked and data saved.
            
            if("external".equals(jType)||("External".equals(jType) )){
        System.out.println("Please enter the  External Job Type: (Leased Worker or 3rd Party) ");
            jexType = in.nextLine();
        
            }
            else{
            jexType = "N/A";
            }
            
            
        System.out.println("Please enter the Job Posistion: (Example AT,ET,Janitor) ");
            jPosistion = in.nextLine();
        System.out.println("Please enter the Job Description: (Explain the basic Job Duties:) ");
            jDescription = in.nextLine();
        System.out.println("Please enter the Job Location: (List city/town Job resides in:) ");
            jLocation = in.nextLine();
        System.out.println("Please enter the Job Schedule: (options 5/40,9/80,7 on/off, part-time:) ");
            jSchedule = in.nextLine();  
       
    } 
    // Method that allows user to review the Job Post before submitting for approval. 
    // This is not needed using the Gui but is needed using the Console.
    public void reviewjPost(){
        jStatus = "Creation";
        System.out.println("Would you like to review Job Post before submitting for approval? (yes or no)");
            reviewAns = in.nextLine();
        if("yes".equals(reviewAns)||("Yes".equals(reviewAns) )){
        System.out.println("Job ID: " + jID);
        System.out.println("Job Type: "+jType);
        if("external".equals(jType)||("External".equals(jType) )){
        System.out.println("External Job Type:" + jexType);
        }
        System.out.println("Job Posistion: " + jPosistion);
        System.out.println("Job Description: " + jDescription);
        System.out.println("Job Location: "+jLocation+" Work Schedule: "+jSchedule);
        System.out.println("Job Post Status: "+jStatus);
        }else{
            
        }
    }  
    
    // Method that sends data from user that is stored in variables to the LinkedList to be used.
    // Method also changes Status of Job Post to Awaiting Approval and gives the Job Post it's ID number
     static public void sendtoApproval(){
        jID = 1+jID;
        //System.out.println("Would you like to send Job Posting for Approval? (Yes/No)");
       // approveAns = in.nextLine();
       // if("yes".equals(approveAns)|| ("Yes".equals(approveAns) )){
        //jStatus = "Awaiting Approval";
        jStatus = "Awaiting Approval";
        
        jobPosting test = new jobPosting(jID,jType,jexType,jPosistion,jDescription,jLocation,jSchedule,jStatus);
        //jobPosting test1 = new jobPosting(05,"internal","n/a","AT","Whatever I want to","mars","5/40","Awaiting Approval");
        //jobPosting test2 = new jobPosting(08,"internal","n/a","ET","I dont know","Jupiter","5/40","Awaiting Approval");
        jP1.add(test);
        //jP1.add(test1);
        //jP1.add(test2);
        System.out.println("Job Post submitted for Approval");
        System.out.println("");
        
       
    //}else{
         
        System.out.println("Job Post not submitted for Approval");
   // }
      
    }
     // this method allows user to delete a Job Posting. The user can only delete
     // Job Postings that are in the Awaiting Approval status. 
     
    static public void removeJPost(int jpID){
        int j = 0;
        for(int i =0;i<jP1.size();i++){
            if("Awaiting Approval".equals(jP1.get(i).getjStatus())){
                j++;
                System.out.println(jP1.get(i));
                System.out.println("-----------------------------------------------");
                
            }
        }System.out.println("There are "+j+" job postings that can be deleted.");
        
        if(j>0){
        
        System.out.println("Please enter job ID to remove: ");
        //jpID = in.nextInt();
        
        for(int i =0;i<jP1.size();i++){
        if(jP1.get(i).getjID()== jpID && "Awaiting Approval".equals(jP1.get(i).getjStatus())){
            //System.out.println(jP1.get(i).getjID());
            jP1.remove(i);
        System.out.println("Job Posting ID: "+ jpID + " has been deleted:");
        
        }
        
        }
       
        
        }
        else
        {
            System.out.println("Job Posting ID "+jpID+" cannot be deleted:");
        }
        }
    
   // public LinkedList<jobPosting> getList(){
    //   return jP1; 
   // }
    // This method allows the viewing of all open approved job postings
    
    public void view(){
        System.out.println("Viewing all Open Job Postings: ");
        System.out.println("");
        System.out.println("There are "+jP1.size()+" approved Job Posts available to view:");
        
        for(int i =0;i<jP1.size();i++){
            System.out.println(jP1.get(i));
            System.out.println("-----------------------------------------------");
        }
       //System.out.println(jP1);     
    }
    public void viewExpedited(){
        if(jP1.size() <= 5){
            for(int i =0;i<jP1.size();i++){
                System.out.println(jP1.get(i));
                System.out.println("-----------------------------------------------");
            }
        }
        else
        {
              for(int i =0; i<5;i++){
            System.out.println(jP1.get(i));
            System.out.println("-----------------------------------------------");  
                }
        
        }       
    }
    // This method allows user to view approved job posts. Due to GUI a new LinkedList is created and then original is searched for all
    // job post that have Approved status and then places them into jP2. Method returns jP2 converted to string for GUI to read.
    static public String viewApproved(){
        int i;
        LinkedList<jobPosting> jP2 = new LinkedList<>();
        for( i =0;i<jP1.size();i++){
            if("Approved".equals(jP1.get(i).getjStatus())){
                System.out.println(jP1.get(i));
                System.out.println("-----------------------------------------------");
                jP2.add(jP1.get(i));
            }
        }
        return jP2.toString();
    }
    // This method allows user to view approved job posts. Due to GUI a new LinkedList is created and then original is searched for all
    // job post that have Awaiting Approval status and then places them into jP4. Method returns jP2 converted to string for GUI to read.
    static public String viewAwaitingApproval(){
        int j = 0;
        int i;
        LinkedList<jobPosting> jP4 = new LinkedList<>();
        for(i =0;i<jP1.size();i++){
            if("Awaiting Approval".equals(jP1.get(i).getjStatus())){
                j++;
                System.out.println(jP1.get(i));
                System.out.println("-----------------------------------------------");
                jP4.add(jP1.get(i));
                
            }
         
        }System.out.println("There are "+j+" job postings awaiting approval.");
        return jP4.toString();
    }
    static public void convertToCSV(jobPosting jP1,String filepath){
        try(FileWriter writer = new FileWriter(filepath)){
            writer.write(jP1.getjID() + ","+jP1.getjType()+ "," +jP1.getjexType()+ "," + jP1.getjPosistion()+ "," + jP1.getjDescription()+ "," + jP1.getjLocation()+ "," + jP1.getjStatus());
        }catch (IOException e){
            e.printStackTrace();
        }
    }
    // This method allows user to view approved job posts. Due to GUI a new LinkedList is created and then original is searched for all
    // job post that have Rejected status and then places them into jP3. Method returns jP2 converted to string for GUI to read.
    static public String viewRejected(){
        LinkedList<jobPosting> jP3 = new LinkedList<>();
        int j = 0;
        for(int i =0;i<jP1.size();i++){
            if("Rejected".equals(jP1.get(i).getjStatus())){
                j++;
                System.out.println(jP1.get(i));
                System.out.println("-----------------------------------------------");
                jP3.add(jP1.get(i));
            }
        }System.out.println("There are "+j+" rejected job postings.");
        return jP3.toString();
    }
    // Method viewJPforDeletion returns a 1 if there is jop posts who's status equals "Awaiting Approval". If there is 0 job posts
    // that have Awaiting "Approval status it will return a 0. This needs to be compared so the delete function can be exited. 
    public int viewJPforDeletion(){
        int j = 0;
        for(int i =0;i<jP1.size();i++){
            if("Awaiting Approval".equals(jP1.get(i).getjStatus())){
                j++;
                System.out.println(jP1.get(i));
                System.out.println("-----------------------------------------------");
                
            }
        }System.out.println("There are "+j+" job postings that can be deleted.");
        if(j > 0){
            return 1;
        }
        else{
            return 0;
        }
                
    }
   
    
    // Method sets the job Post to Approved Status. By using a for loop to 
    // look through the Linked List JP1 an IF statement to find the Job Post ID number
    // the user wants to approve no matter the index of the record.
    static public void jPostIDCheck(int jpID){
        //System.out.println("Please enter a Job ID to approve. ");
       try{
        
        for(int i =0;i<jP1.size();i++){
        if(jP1.get(i).getjID()== jpID){
            //System.out.println(jP1.get(i).getjID());
        jP1.get(i).setjStatus("Approved");
        System.out.println("Job Post ID "+jpID+" was approved:");
        }
        
        }
    
            
       }
       catch(Exception e){
           System.out.println("Job Post ID "+jpID+" was not approved:");
       }
    }
            
        
        
        
    // Method sets the job Post to Approved Status. By using a for loop to 
    // look through the Linked List JP1 an IF statement to find the Job Post ID number
    // the user wants to reject no matter the index of the record.        
    static public void jPostreject(int jpID){
        try{
        //System.out.println("Please enter a Job ID to reject. ");
        //jpID = jpID -1;
        for(int i =0;i<jP1.size();i++){
        if(jP1.get(i).getjID()== jpID){
            //System.out.println(jP1.get(i).getjID());
        jP1.get(i).setjStatus("Rejected");
        }
       
        
        }
        
        
        
    }
    catch (Exception e){
        System.out.println("Enter a valid Job Post ID:");
    }
    }
    // this method saves records in LinkedList to a .txt file.
    // does not save in correct format right now. 
   static public void jPostSave()throws Exception{
       try{
       FileOutputStream fout = new FileOutputStream("C:\\Users\\Public\\Documents\\JPHData\\jPostdata.csv");
       ObjectOutputStream out = new ObjectOutputStream(fout);
       
       out.writeObject(jP1);
      
       fout.close();
       }
       catch (Exception e){
           System.out.println("Error Saving");
       }
       System.out.println("Data Saved");
        }
   
   static public void jPostLoad () throws Exception {
       FileInputStream fin = new FileInputStream("C:\\Users\\Public\\Documents\\JPHData\\jPostdata.csv");
       ObjectInputStream in = new ObjectInputStream(fin);
       
      jP1 = ((LinkedList<jobPosting>)in.readObject());
      
       fin.close();
       System.out.println("Data Loaded");
       jID = jP1.size();
           
       }
       
       
           
       
   
    
    
       
   // public void jPostLoad(){
   //     FileInputStream fis = new FileInputStream("jPostdata.txt");
   //     ObjectInputStream ois = new ObjectInputStream(fis);
   //     LinkedList<jobPosting> jP1 = ois.readObject();
        
        
        
   // }
    
    
    
  // public void remove(){
     //  jP1.remove(0);
       
  // }
    public void setjStatus(String jStatus){
     this.jStatus = jStatus;
    }
    public String getjStatus(){
        return jStatus;
}
    public int getjID(){
        return jID;
}       
 public String getjType(){
        return jType;
}            
}       
    
    
 